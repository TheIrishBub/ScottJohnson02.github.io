def Kanye_Gameover():
    print ("""@@@@@@@@@@@@@@@@@@@@@@@@@@@@####++++''';;:::,::,,,,::;;''''++++###@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@###++++''';;:::,:,.,.,::;;;;'''+++####@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@####+++++''';;:::,,,...,:::::;'''+++####@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@####+++++'''';;::..,..`.,:;;;;'''++++####@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@####+++++''';;;::,,...`..,:;;;'''++++#+##@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####++++''';;;:,,...``,.,::;;'''++++####@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####++++''';;;:,,........,:;''''++++#+##@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####++++''';;;:.......,.,::;;''+++++#+##@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####++++'';;;;:....,...`.:,:;'''++++#+##@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####++++''';;::....`.....,,;;'''++++#+##@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####+#+'''';;:,..,:,..,...,:;;''+++++###@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@######+''';;;;:,...`.,,,.,,,:;;''+++++###@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@######+'';;;;;:,..``.......,:;;''+++++###@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@##@#####+++++''';:...`.`,.`..,:;;'''+++###@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@#'##########+##+'':,.,.,...,,:,;;''''++###@@@@@@@@@@@@@@@@@@@@@@@@#
@@@@@@@@@@@@@@@@@@@@@@@@@#++#####@##+####+#+':,,,,,,;:;;;;'''''+###@@@@@@@@@@@@@@@@@@@@@@@@#
@@@@@@@@@@@@@@@@@@@@@@@@@'#+########++######+;;:::::;;;'++'+++++###@@@@@@@@@@@@@@@@@@@@@##;'
@@@@@@@@@@@@@@@@@@@@@@@@@;#+##+#+#++'''+'+###+;;;;;;''++###########@@@@@@@@@@@@@@@@@@@@@@@@;
@@@@@@@@@@@@@@@@@@@@@@@@@'++#++++###+#@@@+++##+';:'''++###@##'#####++@@@@@@@@@@@@@@@@@@@@@#;
@@@@@@@@@@@@@@@@@@@@@@@@@'+##+++++#@:..#@#@++##''''+#+++++'++######'@@@@@@@@@@@@@@@@@@@@@@##
@@@@@@@@@@@@@@@@@@@@@@@@@#;+#++'''#++.`##@.;;++'';'+++#,.@#+##+#####'@@@@@@@@@@@@@@@@@@@@@@+
@@@@@@@@@@@@@@@@@@@@@@@@@#:'#+'';;'+';':,:'::+';::;+#,@'.@##@######+@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@#@@@@@@@@@@+:+##'';;;'++'''++:''';::;++.:+. @#;@#+++#;@@@@@@@@@@@@@@@@@@@@@@@#
@@@@@@@@@@@@@@@@@@@@@@@@@#;@#+';;;:;''''+',;'';:,:;'':+':+'#+#+''+#,@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@#'##+'';;::::::::;';;;:`::''+;'+'''#+'''+#+@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@+##+'';:::::::::;'';;:.,;;'+;;;'+''''''+#@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@###++';::,,,,,::;'';;:,,:;'+;;;;;;;;'''+#@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@##++'';:::::,,;;'';;:,::;'+';;;;;;;;'++#@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@##++'';;;,::,::''+';:::;;'+':;:::;;;'++#@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@##++'';;:::::,:'+'';::;;''+'';;::;;''+##@@@@@@@@@@@@@@@@@@@@@@@@+
@@@@@@@@@@@@@@@@@@@@@@@@@@@###+'';':;,:,::';'';:,:;''';:;;:;;;'++##@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@####++'';;::,:::';;'::`:;'';':;::;''+++#@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@####++'';;;::,,.';,;;:::;';;#:;::''+++##@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@####++''';;:;,,.+;;'';;:;';;+;;:;''+++##@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@###+++''';:,,,,@#@@@+';+@@+@:;;;''++###@@@@@@@@##@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@###+++''';;::';;;;':#@@@##@';;;;'+++###@@@@@######@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@###+++'''''';;;;''++;;;++'';;;;''+++###@@@@##+++###@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@##++++''++;';:'#@''#;+##'';''+'+++###@@@@@##+++####@@@@@@@@@#@#'
@@@@@@@@@@@@@@@@@@@@@@@@@@@@##+#++''+''''++#+;,+#+###+'''+++++###@@@@###++#+###@@@@@@@@@@@''
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@##++++++';+#+;;''';:'++##+''++++###@@@@@#@#++##@##@@@@@@@@@#+;'
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@##++++++'#+''++++'''''+'##+'++++###@@@@@####+######@@@@@@@@#;;'
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@###++++'+'###++++''+'++'##++++###@@@@@@####+#+####@@@@@@';;:;'
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@####++'#++';:,:::##+##++++++++#+#@@@@@@###########@@@+';:;;;;'
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@###+++#+;';;;:,:;::'+''+#+++++#@@@@@@#############+''''::,;''
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@####+#+';'+';;:,:,:';+++#@'++##@@@@@@####+++++##''';:;'';;;''
@@@@@@#@@@@@@@@@@@@@@@@@@@@@@@#@######+''+++';;;;;'+'''+#+++##@@@@@#@#+####+++';::;;;;;;;;;'
@@@@###@@@@@@@@@@@@@@@@@@@@@@@#@#######++++#######++'++##++#@@@@@@@@@####+++';;:,::::::;;;;;
@@@####@@@@@@@@@@@@@@@@@@@@@;@#@@########++####@#@#++++######@###@@@#####++';;:,:::::::;';;;
@@#+###@@@@@@@@@@@@@@@@@#@:.@@##@#######@####+++''########@#@,##@@.'@#####';;::,::::::::;;;;
@@#+####@@@@@@@@@@@@@@@@`.@+#;##@@@#####@#++;;+####@@####@#@@`+###+``.###';:;,:,,:,:::::::;;
#@#++####@@@@@@@@@@@@@,`.:++#@###@@@#@@##+#++++######@##@@###;####++`.`;:;':::;:,,,:::::::;'
###+++####@@@@@@@@@@```.`#++'###+#@@@########@#####@@@####++#;++#+++```.`;,;:::::,,,::::::::
###+++###@@@@@@@@# ``````++#@@###+@@##+#+#@#####+####@@#@+#+@,+@+++:` ``. ,:::::::,,,:::::::
###++####@@@@#@, ``````` +';####++#@@###@####@##########+++++.##+'' ` ```.` ::::::,,,,::::::
@########@@@@` `````````.+:;#####++#@@################@++++##;'@''#``  `````` ;:,:,.:,::::::
#@########@```.`````` ``+';@#####+++@@@@##@#@#######@@@+++++':+@';    ``````````,,:.,,::::::
#@####### `.`.``````````''.@+##+#+++#@@@@@##@####@@@@@#+++++.:+,++    ```````````,,,.,::::::
#@###@. ``.`````````````'++@'##++++++#@@@@@@@#@@@@@@@#++'''++#++'``   ``````````.. :,,::::,;
@##' .`..```````````````'::#@#++++++++#@@@@@@@@@@@@@#+''''''`'##.`     ```````````.`,.,::@@#
What would the second option do..... I guess we'll never know ~~ Kanye""")



def beach_option():
    print('You have decided to head towards the beach. Do you head north or south?')
    answer = int(input('Enter 1 for north or enter 2 for south.'))

    if answer == 1:
        print('you see a boat')
        answer = int(input('Enter 1 for swim to the boat or enter 2 for signal the boat.'))
        if answer == 1:
            print('you try to swim towards the boat but the boat passes you and you drown in the ocean. ')
            answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
            if answer == 1:
                #newgame
                Kanye_Gameover()
                print()
            if answer == 2:
                beach_option()
        if answer == 2:
            print('You try and signal the boat and the boat keeps going.')
            answer = int(input('Enter 1 to search for firewood or enter 2 to search for reflection object.'))
            if answer == 1:
                print('You found some firewood.')
                answer = int(input('Enter 1 to use 2 pieces of wood or enter 2 to use 5 pieces.'))
                if answer == 1:
                    print ('They see you, but it will take 3 days to get to you.')
                    answer = int(input('Enter 1 to live on the coast or enter 2 to live in the woods until help arrives.'))
                    if answer == 1:
                        print ('You need to eat to survive. What food do you choose?')
                        answer = int(input('Enter 1 to eat coconuts or enter 2 to eat bananas.'))
                        if answer == 1:
                            print ('Yummy! You lived off of the coconuts for 3 days and help is finally here. Congrats, you escaped the island.')
                        if answer == 2:
                            print (" As you open the bananas, a wild gorilla appears and beats you up. You die.")
                            answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                            if answer == 1:
                                #newgame
                                Kanye_Gameover()
                                print()
                            if answer == 2:
                                beach_option()
                    if answer == 2:
                        print ('A gorrilla senses your smell on its boundary and attacks you. You die.')
                        answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                        if answer == 1:
                            Kanye_Gameover()
                            #newgame
                            print()
                        if answer == 2:
                            beach_option()
                if answer == 2:
                    print ('You used too many pieces of wood. Unfortunetly, the fire spread too quickly and you burned yourself alive.')
                    answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                    if answer == 1:
                        #newgame
                        Kanye_Gameover()
                        print()
                    if answer == 2:
                        beach_option()
            if answer == 2:
                print ('You could not find any reflection objects. You are now stranded on the island with no hope for escape. You die.')
                answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                if answer == 1:
                    #newgame
                    Kanye_Gameover()
                    print()
                if answer == 2:
                    beach_option()
            
            
    if answer == 2:
        print('you see 2 planes')
        answer = int(input('Enter 1 to run after it or enter 2 to keep searching the beach.'))
        if answer == 1:
            print('One plane goes towards the jungle and another goes towards the coast.')
            answer = int(input('Enter 1 go towards the jungle or enter 2 to run along the coast.'))
            if answer == 1:
                print ('You are lost and you see a gorilla!')
                answer = int(input('Enter 1 to confront the gorilla or enter 2 to run away.'))
                if answer == 1:
                    print ('The gorilla easily kills you. You die.')
                    answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                    if answer == 1:
                        #newgame
                        Kanye_Gameover()
                        print()
                    if answer == 2:
                        beach_option()
                if answer == 2:
                    print ('The gorilla easily kills you. You die.')
                    answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                    if answer == 1:
                        #newgame
                        Kanye_Gameover()
                        print()
                    if answer == 2:
                        beach_option()
            if answer == 2:
                print ('You are sprinting along the coast and you tripped')
                answer = int(input('Enter 1 to break the fall with your hands or enter 2 to break the fall with your face.'))
                if answer == 1:
                    print ('You landed on a poisonous shell and an allergic reaction ocurred. You die.')
                    answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                    if answer == 1:
                        #newgame
                        Kanye_Gameover()
                        print()
                    if answer == 2:
                        beach_option()
                if answer == 2:
                    print ('You landed on a poisonous shell and an allergic reaction ocurred. You die.')
                    answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                    if answer == 1:
                        #newgame
                        Kanye_Gameover()
                        print()
                    if answer == 2:
                        beach_option()
        if answer == 2:
            print ('You come across a compass.')
            answer = int(input('Enter 1 to pick up the compass or enter 2 to leave it.'))
            if answer == 1:
                print ('you pick up the compass and you see another plane flying over head')
                answer = int(input('Enter 1 to reflect the light at the pilot or enter 2 to run after it.'))
                if answer == 1:
                    print( 'the plane sees you but it will take a few days for a search team deployed')
                    answer = int(input('Enter 1 to live off of mysterious berries or enter 2 to eat bananas until help arrives.'))
                    if answer == 1:
                        print("it turns out htey were sea grapes. Help arrives 3 days later and you make it off the island. You win!")
                    if answer == 2:
                        print (" As you open the bananas, a wild gorilla appears and beats you up. You die.")
                        answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                        if answer == 1:
                            #newgame
                            Kanye_Gameover()
                            print()
                        if answer == 2:
                            beach_option()
                if answer == 2:
                    answer = int(input('Enter 1 go towards the jungle or enter 2 to run along the coast.'))
                    if answer == 1:
                        print ('You are lost and you see a gorilla!')
                        answer = int(input('Enter 1 to confront the gorilla or enter 2 to run away.'))
                        if answer == 1:
                            print ('The gorilla easily kills you. You die.')
                            answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                            if answer == 1:
                                #newgame
                                Kanye_Gameover()
                                print()
                            if answer == 2:
                                beach_option()
                        if answer == 2:
                            print ('The gorilla easily kills you. You die.')
                            answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                            if answer == 1:
                                #newgame
                                Kanye_Gameover()
                                print()
                            if answer == 2:
                                beach_option()
                    if answer == 2:
                        print ('You are sprinting along the coast and you tripped')
                        answer = int(input('Enter 1 to break the fall with your hands or enter 2 to break the fall with your face.'))
                        if answer == 1:
                            print ('You landed on a poisonous shell and an allergic reaction ocurred. You die.')
                            answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                            if answer == 1:
                                #newgame
                                Kanye_Gameover()
                                print()
                            if answer == 2:
                                beach_option()
                        if answer == 2:
                            print ('You landed on a poisonous shell and an allergic reaction ocurred. You die.')
                            answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                            if answer == 1:
                                #newgame
                                Kanye_Gameover()
                                print()
                            if answer == 2:
                                beach_option()
                
            if answer == 2:
                print ('you see some logs laying on the coast')
                answer = int(input('Enter 1 to use palm tree leaves to make a raft or enter 2 to use thin strips of bark to tie them.'))
                if answer ==1:
                    print ('you are able to tie the logs together and you embark on your sea voyage but you are then ambushed by a storm and your boat sinks. You die.')
                    answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                    if answer == 1:
                        #newgame
                        Kanye_Gameover()
                        print()
                    if answer == 2:
                        beach_option()
                if answer ==2:
                    print ('you are able to tie the logs together and you embark on your sea voyage but you are then ambushed by a storm and your boat sinks. You die.')
                    answer = int(input('Enter 1 for new game or enter 2 to try the beach again.'))
                    if answer == 1:
                        #newgame
                        Kanye_Gameover()
                        print()
                    if answer == 2:
                        beach_option()
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    else:
        print('You have decided to head towards the beach. Do you head north or south?')
        answer = int(input('Enter 1 for north or enter 2 for south.'))
        beach_option()
        

beach_option()



def Kanye_Gameover():
    print ("""@@@@@@@@@@@@@@@@@@@@@@@@@@@@####++++''';;:::,::,,,,::;;''''++++###@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@###++++''';;:::,:,.,.,::;;;;'''+++####@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@####+++++''';;:::,,,...,:::::;'''+++####@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@####+++++'''';;::..,..`.,:;;;;'''++++####@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@####+++++''';;;::,,...`..,:;;;'''++++#+##@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####++++''';;;:,,...``,.,::;;'''++++####@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####++++''';;;:,,........,:;''''++++#+##@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####++++''';;;:.......,.,::;;''+++++#+##@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####++++'';;;;:....,...`.:,:;'''++++#+##@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####++++''';;::....`.....,,;;'''++++#+##@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@#####+#+'''';;:,..,:,..,...,:;;''+++++###@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@######+''';;;;:,...`.,,,.,,,:;;''+++++###@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@######+'';;;;;:,..``.......,:;;''+++++###@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@##@#####+++++''';:...`.`,.`..,:;;'''+++###@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@#'##########+##+'':,.,.,...,,:,;;''''++###@@@@@@@@@@@@@@@@@@@@@@@@#
@@@@@@@@@@@@@@@@@@@@@@@@@#++#####@##+####+#+':,,,,,,;:;;;;'''''+###@@@@@@@@@@@@@@@@@@@@@@@@#
@@@@@@@@@@@@@@@@@@@@@@@@@'#+########++######+;;:::::;;;'++'+++++###@@@@@@@@@@@@@@@@@@@@@##;'
@@@@@@@@@@@@@@@@@@@@@@@@@;#+##+#+#++'''+'+###+;;;;;;''++###########@@@@@@@@@@@@@@@@@@@@@@@@;
@@@@@@@@@@@@@@@@@@@@@@@@@'++#++++###+#@@@+++##+';:'''++###@##'#####++@@@@@@@@@@@@@@@@@@@@@#;
@@@@@@@@@@@@@@@@@@@@@@@@@'+##+++++#@:..#@#@++##''''+#+++++'++######'@@@@@@@@@@@@@@@@@@@@@@##
@@@@@@@@@@@@@@@@@@@@@@@@@#;+#++'''#++.`##@.;;++'';'+++#,.@#+##+#####'@@@@@@@@@@@@@@@@@@@@@@+
@@@@@@@@@@@@@@@@@@@@@@@@@#:'#+'';;'+';':,:'::+';::;+#,@'.@##@######+@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@#@@@@@@@@@@+:+##'';;;'++'''++:''';::;++.:+. @#;@#+++#;@@@@@@@@@@@@@@@@@@@@@@@#
@@@@@@@@@@@@@@@@@@@@@@@@@#;@#+';;;:;''''+',;'';:,:;'':+':+'#+#+''+#,@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@#'##+'';;::::::::;';;;:`::''+;'+'''#+'''+#+@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@+##+'';:::::::::;'';;:.,;;'+;;;'+''''''+#@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@###++';::,,,,,::;'';;:,,:;'+;;;;;;;;'''+#@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@##++'';:::::,,;;'';;:,::;'+';;;;;;;;'++#@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@##++'';;;,::,::''+';:::;;'+':;:::;;;'++#@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@##++'';;:::::,:'+'';::;;''+'';;::;;''+##@@@@@@@@@@@@@@@@@@@@@@@@+
@@@@@@@@@@@@@@@@@@@@@@@@@@@###+'';':;,:,::';'';:,:;''';:;;:;;;'++##@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@####++'';;::,:::';;'::`:;'';':;::;''+++#@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@####++'';;;::,,.';,;;:::;';;#:;::''+++##@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@####++''';;:;,,.+;;'';;:;';;+;;:;''+++##@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@###+++''';:,,,,@#@@@+';+@@+@:;;;''++###@@@@@@@@##@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@###+++''';;::';;;;':#@@@##@';;;;'+++###@@@@@######@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@###+++'''''';;;;''++;;;++'';;;;''+++###@@@@##+++###@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@##++++''++;';:'#@''#;+##'';''+'+++###@@@@@##+++####@@@@@@@@@#@#'
@@@@@@@@@@@@@@@@@@@@@@@@@@@@##+#++''+''''++#+;,+#+###+'''+++++###@@@@###++#+###@@@@@@@@@@@''
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@##++++++';+#+;;''';:'++##+''++++###@@@@@#@#++##@##@@@@@@@@@#+;'
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@##++++++'#+''++++'''''+'##+'++++###@@@@@####+######@@@@@@@@#;;'
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@###++++'+'###++++''+'++'##++++###@@@@@@####+#+####@@@@@@';;:;'
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@####++'#++';:,:::##+##++++++++#+#@@@@@@###########@@@+';:;;;;'
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@###+++#+;';;;:,:;::'+''+#+++++#@@@@@@#############+''''::,;''
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@####+#+';'+';;:,:,:';+++#@'++##@@@@@@####+++++##''';:;'';;;''
@@@@@@#@@@@@@@@@@@@@@@@@@@@@@@#@######+''+++';;;;;'+'''+#+++##@@@@@#@#+####+++';::;;;;;;;;;'
@@@@###@@@@@@@@@@@@@@@@@@@@@@@#@#######++++#######++'++##++#@@@@@@@@@####+++';;:,::::::;;;;;
@@@####@@@@@@@@@@@@@@@@@@@@@;@#@@########++####@#@#++++######@###@@@#####++';;:,:::::::;';;;
@@#+###@@@@@@@@@@@@@@@@@#@:.@@##@#######@####+++''########@#@,##@@.'@#####';;::,::::::::;;;;
@@#+####@@@@@@@@@@@@@@@@`.@+#;##@@@#####@#++;;+####@@####@#@@`+###+``.###';:;,:,,:,:::::::;;
#@#++####@@@@@@@@@@@@@,`.:++#@###@@@#@@##+#++++######@##@@###;####++`.`;:;':::;:,,,:::::::;'
###+++####@@@@@@@@@@```.`#++'###+#@@@########@#####@@@####++#;++#+++```.`;,;:::::,,,::::::::
###+++###@@@@@@@@# ``````++#@@###+@@##+#+#@#####+####@@#@+#+@,+@+++:` ``. ,:::::::,,,:::::::
###++####@@@@#@, ``````` +';####++#@@###@####@##########+++++.##+'' ` ```.` ::::::,,,,::::::
@########@@@@` `````````.+:;#####++#@@################@++++##;'@''#``  `````` ;:,:,.:,::::::
#@########@```.`````` ``+';@#####+++@@@@##@#@#######@@@+++++':+@';    ``````````,,:.,,::::::
#@####### `.`.``````````''.@+##+#+++#@@@@@##@####@@@@@#+++++.:+,++    ```````````,,,.,::::::
#@###@. ``.`````````````'++@'##++++++#@@@@@@@#@@@@@@@#++'''++#++'``   ``````````.. :,,::::,;
@##' .`..```````````````'::#@#++++++++#@@@@@@@@@@@@@#+''''''`'##.`     ```````````.`,.,::@@#
What would the second option do..... I guess we'll never know ~~ Kanye""")
  